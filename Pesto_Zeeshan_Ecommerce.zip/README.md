install Node.js, open this folder in the terminal and do

`npm i`

## Available Scripts

In the project directory, you can run:

### `npm start`

Runs the app in the development mode.\
Open [http://localhost:3000](http://localhost:3000) to view it in the browser.

The page will reload if you make edits.\
You will also see any lint errors in the console.

### `OR`

You can find this site hosted at

[https://ecommerce-xyz.web.app/]

For testing notification, login with google or email and password, then allow notifications and goto notification test from the footer or
[https://ecommerce-xyz.web.app/notification](login needed!)

The application detects your location and sets the currency and symbol accordingly.

for the scratch card, login, add any item to the cart, goto cart and click on buy or
[https://ecommerce-xyz.web.app/rewards]


For language selection goto language selection from footer, or navbar(once logged in)