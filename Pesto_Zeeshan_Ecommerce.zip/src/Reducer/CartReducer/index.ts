const initialState: string[] = [];

export default function CartReducer(state = initialState, action: any) {
  return 1;
}

// export const x= "2"
